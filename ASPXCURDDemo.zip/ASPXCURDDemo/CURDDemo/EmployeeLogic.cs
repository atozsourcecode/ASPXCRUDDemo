﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CURDDemo
{
    public class EmployeeLogic : SQLHelper
    {
        public MEMBERS.SQLReturnMessageNValue Employee_Insert(EmployeeClass model)
        {
            return ExecuteProceduerWithMessageNValue("Employee_Insert", new object[,] { { "Name", model.Name }, { "MobileNo", model.MobileNo } }, 2);
        }

        public MEMBERS.SQLReturnMessageNValue Employee_Update(EmployeeClass model)
        {
            return ExecuteProceduerWithMessageNValue("Employee_Update", new object[,] { { "ID", model.ID }, { "Name", model.Name }, { "MobileNo", model.MobileNo } }, 2);
        }

        public MEMBERS.SQLReturnMessageNValue Employee_Delete(int ID)
        {
            return ExecuteProceduerWithMessageNValue("Employee_Delete", new object[,] { { "ID", ID } }, 2);
        }

        public DataTable Employee_Get(int ID)
        {
            return GetAll_DataTable("Employee_Get", new object[,] { { "ID", ID } });
        }

        public DataTable Employee_GetAll()
        {
            return GetAll_DataTable("Employee_GetAll", new object[,] { });
        }
    }
}
