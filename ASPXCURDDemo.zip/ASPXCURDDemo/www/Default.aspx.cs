﻿using CURDDemo;
using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Get_GetAll(0);
        }
    }

    protected void rptData_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        Int32 mEmpID = 0;

        if (!string.IsNullOrEmpty(e.CommandArgument.ToString()))
        {
            switch (e.CommandName)
            {
                case "cmdEdit":
                    Int32.TryParse(e.CommandArgument.ToString(), out mEmpID);

                    DataTable dt = Get_GetAll(mEmpID);

                    if (dt.Rows.Count > 0)
                    {
                        EmpID.Value = e.CommandArgument.ToString();
                        tbEmployeeName.Text = dt.Rows[0]["Name"].ToString();
                        tbMobileNo.Text = dt.Rows[0]["MobileNo"].ToString();
                    }
                    break;
                case "cmdDelete":
                    Int32.TryParse(e.CommandArgument.ToString(), out mEmpID);

                    string Message = Delete(mEmpID);

                    Page.ClientScript.RegisterStartupScript(this.GetType(), "DynamicMessageAlert", "CallWithDynamicMessage('" + Message + "');", true);

                    Get_GetAll(0);
                    break;
            }
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        string Message = string.Empty;

        Int32 mEmpID = 0;
        Int32.TryParse(EmpID.Value, out mEmpID);

        EmployeeClass obj = new EmployeeClass();
        obj.ID = mEmpID;
        obj.Name = tbEmployeeName.Text;
        obj.MobileNo = tbMobileNo.Text;

        if (mEmpID == 0)
            Message = Save(obj);
        else
            Message = Update(obj);

        ClearControls();

        Page.ClientScript.RegisterStartupScript(this.GetType(), "DynamicMessageAlert", "CallWithDynamicMessage('" + Message + "');", true);

        Get_GetAll(0);
    }

    public string Save(EmployeeClass modal)
    {
        MEMBERS.SQLReturnMessageNValue mRes = new EmployeeLogic().Employee_Insert(modal);
        return mRes.Outmsg.ToString();
    }

    public string Update(EmployeeClass modal)
    {
        MEMBERS.SQLReturnMessageNValue mRes = new EmployeeLogic().Employee_Update(modal);
        return mRes.Outmsg.ToString();
    }

    public DataTable Get_GetAll(Int32 ID)
    {
        DataTable dt = new DataTable();

        if (ID > 0)
        {
            dt = new EmployeeLogic().Employee_Get(ID);
        }
        else
        {
            dt = new EmployeeLogic().Employee_GetAll();

            rptData.DataSource = dt;
            rptData.DataBind();
        }
        return dt;
    }

    public string Delete(Int32 ID)
    {
        MEMBERS.SQLReturnMessageNValue mRes = new EmployeeLogic().Employee_Delete(ID);
        return mRes.Outmsg.ToString();
    }

    public void ClearControls()
    {
        EmpID.Value = "0";
        tbEmployeeName.Text = tbMobileNo.Text = string.Empty;
    }
}